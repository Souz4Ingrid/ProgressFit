package model;

// A classe Pix implementa a interface Pagamento, fornecendo a implementação do método realizarPagamento
public class Pix implements Pagamento {

    // Processa o pagamento via Pix
    @Override
    public void realizarPagamento(double valor) {
        System.out.println("Pagamento via Pix no valor de R$" + valor);
    }
}
