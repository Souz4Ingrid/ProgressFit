package model;
public class Hipertrofia extends Treino {
    @Override
    public void exibirDetalhes() {
        System.out.println("Treino de Hipertrofia: Crossfit e Musculação");
    }
}
