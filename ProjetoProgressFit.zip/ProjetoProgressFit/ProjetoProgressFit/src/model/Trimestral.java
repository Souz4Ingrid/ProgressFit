package model;

// A classe Trimestral é da classe Plano e fornece uma implementação do método exibirDetalhes.
public class Trimestral extends Plano {

    @Override
    public void exibirDetalhes() {
        System.out.println("Plano Trimestral: R$300 a cada 3 meses.");
    }
}
