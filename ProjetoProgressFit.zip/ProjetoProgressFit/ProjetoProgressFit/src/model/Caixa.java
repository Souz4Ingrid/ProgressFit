package model;

// Classe Caixa processa os pagamentos
public class Caixa {

    // Método público chamado processarPagamento
    // Recebe um objeto do tipo Pagamento e um valor do tipo double
    public void processarPagamento(Pagamento pagamento, double valor) {

        // Chama o método realizarPagamento do objeto recebido
        // É executado conforme a forma de pagamento usada (Pix, Cartão ou Dinheiro)
        pagamento.realizarPagamento(valor);

        System.out.println("Pagamento registrado no sistema com sucesso.");
    }
}
