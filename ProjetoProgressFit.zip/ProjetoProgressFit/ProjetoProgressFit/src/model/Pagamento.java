// Interface do "Model"
package model;

// Realizar pagamento
// Qualquer classe que implementar essa interface deve fornecer uma implementação do método realizarPagamento
public interface Pagamento {

    // Método abstrato deve ser implementado pelas classes que implementam a interface Pagamento
    // Esse método recebe um valor e processa o pagamento
    void realizarPagamento(double valor);
}
