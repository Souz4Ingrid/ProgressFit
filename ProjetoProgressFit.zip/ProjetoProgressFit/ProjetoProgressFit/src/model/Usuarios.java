package model;

// A classe Usuarios é abstrata, não pode ser instanciada diretamente.
// Ela serve como uma classe base para outros tipos de usuários, como Aluno, Professor, Funcionario, etc.
public abstract class Usuarios {

    // Atributos que armazenam o nome e CPF de um usuário
    //"protected" significa que essas variáveis podem ser acessadas por classes dentro do mesmo pacote ou por subclasses
    protected String nome;
    protected String cpf;

    // Construtor da classe Usuarios que inicializa os atributos nome e cpf
    // O construtor é chamado ao criar uma instância de uma classe filha (como Aluno ou Professor)
    public Usuarios(String nome, String cpf) {
        this.nome = nome;
        this.cpf = cpf;
    }
    // Cada tipo de usuário (como Aluno ou Professor) fornecerá sua própria implementação deste método
    public abstract void exibirDados();
}
