package model;

public class Cardiovascular extends Treino {
    @Override
    public void exibirDetalhes() {
        System.out.println("Treino Cardiovascular: Foco em caminhada, ciclismo, corrida, dança, Jump, entre outros.");
    }
}
