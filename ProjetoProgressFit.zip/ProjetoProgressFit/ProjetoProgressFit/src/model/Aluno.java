// Classe faz parte do "model"
package model;

// A classe Aluno herda da classe Usuarios (herança)
public class Aluno extends Usuarios {

    public String getCpf() {
        return this.cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    // Classe Aluno recebe nome e cpf
    // Ele chama o construtor da superclasse (Usuarios) usando super()
    public Aluno(String nome, String cpf) {
        super(nome, cpf); // Envia os dados para o construtor da classe pai (Usuarios)
    }

    // (Polimorfismo) Cada classe pode exibir os dados do seu jeito
    @Override
    public void exibirDados() {
        // Exibe os dados do aluno no console com nome e CPF
        System.out.println("Aluno: " + nome + " | CPF: " + cpf);
    }
}
