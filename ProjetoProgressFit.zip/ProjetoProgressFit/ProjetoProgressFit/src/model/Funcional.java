package model;

public class Funcional extends Treino {

    @Override
    public void exibirDetalhes() {

        System.out.println("Treino Funcional: Foco em Agachamentos, exercícios com Halter, pular corda," +
                "saltos, entre outros.");
    }
}
