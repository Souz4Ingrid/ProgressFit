package model;
public class Musculação extends Equipamentos{
    @Override
    public void exibirDetalhes() {
        System.out.println("Equipamentos de Musculação: Halteres, Barras e Anilhas, Leg Press," +
                "Cadeixa Flexora e Extensora, Remada, Supino. ");
    }
}
