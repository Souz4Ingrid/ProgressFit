package model;

public class EquipCardio extends Equipamentos {
    @Override
    public void exibirDetalhes() {
        System.out.println("Equipamentos Cardiovasculares: Esteiras, Bicicletas ergométricas, Escada.");
    }
}
