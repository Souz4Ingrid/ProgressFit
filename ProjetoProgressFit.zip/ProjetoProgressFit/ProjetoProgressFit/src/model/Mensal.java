package model;

public class Mensal extends Plano {

    @Override
    public void exibirDetalhes() {
        System.out.println("Plano Mensal: R$100/mês");
    }
}
