package model;

// A classe Plano é abstrata, não pode ser instanciada diretamente.
// Ela serve como uma classe base para outros tipos de plano, que devem fornecer a implementação de exibirDetalhes.
public abstract class Plano {

    // Método abstrato que deve ser implementado pelas subclasses de Plano
    // Cada tipo de plano (Mensal, Anual, etc.) fornecerá sua própria implementação de exibição dos detalhes do plano.
    public abstract void exibirDetalhes();
}
