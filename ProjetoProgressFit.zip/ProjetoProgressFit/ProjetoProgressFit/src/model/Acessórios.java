package model;

public class Acessórios extends Equipamentos{
    @Override //Indica que ta substituindo um método da classe mãe
             // em uma classe filha que é a subclasse
    public void exibirDetalhes() {
        //Não retorna nenhum valor (void) e é subescrito
        //na subclasse para mostrar informaçoes específicas
        System.out.println("Acessórios: Corda, band, step, bolas, colchonetes.");
    }
}
