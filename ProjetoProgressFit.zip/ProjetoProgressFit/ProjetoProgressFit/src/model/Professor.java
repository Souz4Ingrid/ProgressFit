package model;

// A classe Professor é a classe Usuarios, e é um tipo de usuario especifico
public class Professor extends Usuarios {

    // Construtor da classe Professor que chama o construtor da classe pai (Usuarios)
    // O construtor recebe o nome e o CPF do professor e passa esses valores para o construtor da classe Usuário.
    public Professor(String nome, String cpf) {
        super(nome, cpf);
    }
    @Override
    public void exibirDados() {
        System.out.println("Professor: " + nome + " | CPF: " + cpf);
    }
}
