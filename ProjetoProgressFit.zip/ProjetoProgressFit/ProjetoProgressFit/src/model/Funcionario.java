package model;

// A classe Funcionario é da classe Usuarios
// Possui as propriedades e métodos de Usuarios, mas com um comportamento específico
public class Funcionario extends Usuarios {

    // Atributo privado para armazenar o setor do funcionário
    private String setor;

    // Construtor da classe Funcionario
    // Recebe o nome, CPF e o setor, e passa nome e CPF para a classe pai (Usuarios)
    public Funcionario(String nome, String cpf, String setor) {
        super(nome, cpf);  // Chama o construtor da classe pai para inicializar nome e cpf
        this.setor = setor; // Inicializa o atributo setor
    }
    @Override
    public void exibirDados() {
        System.out.println("Funcionario: " + nome + " | CPF: " + cpf + " | Setor: " + setor);
    }
}
