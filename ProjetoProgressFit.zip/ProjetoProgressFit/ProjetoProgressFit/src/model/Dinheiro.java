package model;
// Classe deve implementar o método realizarPagamento
public class Dinheiro implements Pagamento {

    @Override
    public void realizarPagamento(double valor) {
        System.out.println("Pagamento em espécie no valor de R$" + valor);
    }
}
