package model;

// A classe Equipamentos é abstrata, ela não pode ser instanciada diretamente
// Apenas outras classes que herdam dela podem ser instanciadas
public abstract class Equipamentos {

    // Método abstrato que deve ser implementado pelas subclasses
    // O método exibirDetalhes só aparecerá nas subclasses
    public abstract void exibirDetalhes();
}
