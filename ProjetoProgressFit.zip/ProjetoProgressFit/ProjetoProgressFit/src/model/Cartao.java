package model;

// A classe Cartao implementa a interface Pagamento
// Isso significa que a classe deve implementar o método realizarPagamento
public class Cartao implements Pagamento {

    @Override
    public void realizarPagamento(double valor) {
        System.out.println("Pagamento via Cartão no valor de R$" + valor);
    }
}
