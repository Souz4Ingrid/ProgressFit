package model;

// A classe Treino é abstrata, não pode ser instanciada diretamente.
// Ela serve como uma classe base para outros tipos de treino, que devem fornecer a implementação de exibirDetalhes.
public abstract class Treino {

    // Método abstrato que deve ser implementado pelas subclasses de Treino
    // Cada tipo de treino (como Hipertrofia, Cardiovascular, etc.) fornecerá sua própria implementação de exibição dos detalhes do treino.
    public abstract void exibirDetalhes();
}
