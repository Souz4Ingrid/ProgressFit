package model;

public class Anual extends Plano {

    @Override
    public void exibirDetalhes() {
        // Exibe detalhes do plano anual com o valor
        System.out.println("Plano Anual: R$1200");
    }
}
