package model;
public class Força extends Treino {

    @Override
    public void exibirDetalhes() {
        System.out.println("Treino de Força: Foco em Crossfit, musculação e definição.");
    }
}
