//Define o pacote onde está o arquivo
package App;

import java.util.ArrayList;

//Importa todas as classes do pacote Model e classe Scanner
import model.*;
import java.util.Scanner;
public class Main {

    public static void main(String[] args) {
        //Cria um objeto Scanner para ler as entradas dos usuarios
        Scanner scanner = new Scanner(System.in);
        int opcao; //Armazena a escolha do usuario

        ArrayList<Usuarios> listaAlunos = new ArrayList<>();

        //Loop do menu princial, continua até o usuario escolher uma opção
        do{
            // Exibe o menu de opções
            System.out.println("\n=== MENU ACADEMIA ===");
            System.out.println("1. Cadastrar Aluno");
            System.out.println("2. Visualizar Treinos");
            System.out.println("3. Visualizar Equipamentos");
            System.out.println("4. Realizar Pagamento");
            System.out.println("5. Listar Alunos Cadastrados");
            System.out.println("6. Remover Aluno");
            System.out.println("7. Alterar Aluno");
            System.out.println("0. Sair");
            System.out.println("Escolha: ");

            //Lê a opção escolhida pelo usuário
            opcao = scanner.nextInt();
            scanner.nextLine(); // Limpa o buffer

            //Switch verifica o valor digitado pelo usuario
            switch (opcao) {
                case 1: // Coloca o numero que vai ser comparado com a variável
                    System.out.print("Nome: ");
                    String nome = scanner.nextLine();
                    System.out.print("CPF: ");
                    String cpf = scanner.nextLine();
                    Usuarios aluno = new Aluno (nome, cpf);
                    aluno.exibirDados();
                    listaAlunos.add(aluno);
                    break; // Encerra e impede que outros cases sejam executados
                case 2:

                    Treino t1 = new Hipertrofia();
                    Treino t2 = new Cardiovascular();
                    Treino t3 = new Força();
                    Treino t4 = new Funcional();
                    t1.exibirDetalhes();
                    t2.exibirDetalhes();
                    t3.exibirDetalhes();
                    t4.exibirDetalhes();
                    break;

                case 3:
                    Equipamentos e1 = new Musculação();
                    Equipamentos e2 = new Acessórios();
                    Equipamentos e3 = new EquipCardio();
                    e1.exibirDetalhes();
                    e2.exibirDetalhes();
                    e3.exibirDetalhes();
                    break;

                case 4:
                    Caixa caixa = new Caixa();
                    System.out.print("Valor do pagamento: ");
                    double valor = scanner.nextDouble();
                    scanner.nextLine();
                    System.out.println("Forma de pagamento: 1-Pix 2-Cartão 3-Dinheiro");
                    int tipo = scanner.nextInt();
                    Pagamento pagamento = null; // Não tem nenhum objeto apontado para ele
                    switch (tipo) {
                        case 1: pagamento = new Pix(); break;
                        case 2: pagamento = new Cartao(); break;
                        case 3: pagamento = new Dinheiro(); break;
                        default: System.out.println("Tipo inválido."); continue;
                    }
                    caixa.processarPagamento(pagamento, valor);
                    break;

                case 5: // Exibir todos os alunos cadastrados
                    if (listaAlunos.isEmpty()) {
                        System.out.println("Nenhum aluno cadastrado.");
                    } else {
                        System.out.println("\n--- Alunos Cadastrados ---");
                        for (Usuarios u : listaAlunos) {
                            u.exibirDados();
                        }
                    }
                    break;

                case 6:
                    System.out.println("Informe o CPF do aluno que deseja remover: ");
                    String cpfRemover = scanner.nextLine();
                    boolean removido = false;

                    for (int i = 0; i < listaAlunos.size(); i++) {
                        if (listaAlunos.get(i) instanceof Aluno) {
                            Aluno a = (Aluno) listaAlunos.get(i);
                            if (a.getCpf().equals(cpfRemover)) {
                                listaAlunos.remove(i);
                                removido = true;
                                System.out.println("Aluno removido com sucesso. ");
                                break;
                            }
                        }
                    }

                    if (!removido) {
                        System.out.println("Aluno com CPF informado não encontrado.");
                    }
                    break;

                case 7:
                    System.out.println("Informe o CPF do aluno que deseja alterar: ");
                    String cpfAlterar = scanner.nextLine();
                    boolean alterado = false;

                    for (Usuarios u : listaAlunos) {
                        if (u instanceof Aluno) {
                            Aluno a = (Aluno) u;
                            if (a.getCpf().equals(cpfAlterar)) {
                                System.out.print("Novo nome (pressione enter para manter o atual): ");
                                String novoNome = scanner.nextLine();
                                if (!novoNome.isEmpty()) {
                                    a.setNome(novoNome);
                                }

                                System.out.print("Novo CPF (pressione enter para manter o atual): ");
                                String novoCpf = scanner.nextLine();
                                if (!novoCpf.isEmpty()) {
                                    a.setCpf(novoCpf);
                                }

                                System.out.println("Dados do aluno atualizado com sucesso.");
                                alterado = true;
                                break;
                            }
                        }
                    }

                    if (!alterado) {
                        System.out.println("Aluno com CPF informado não encontrado.");
                    }
                    break;

                case 0:
                    System.out.println("Saindo...");
                    break;
                default: //Caso o usuario digite uma opção inválida
                    System.out.println("Opção inválida.");
            }
        } while (opcao !=0); //Enquanto a opção não for 0, continua exibindo o menu

        scanner.close(); //Fecha o scanner para evitar vazamento de recursos.
    }
}

